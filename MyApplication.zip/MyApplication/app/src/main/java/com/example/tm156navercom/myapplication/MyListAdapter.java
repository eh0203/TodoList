package com.example.tm156navercom.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by HOON on 2017-11-13.
 */

public class MyListAdapter extends BaseAdapter {
    Context context;
    ArrayList<list_item> list_itemArrayList;

    TextView txtName;
    TextView txtTitle;
    TextView txtDate;
    TextView txtContent;
    ImageView imgProfile;

    public MyListAdapter(Context context, ArrayList<list_item> list_itemArrayList) {
        this.context = context;
        this.list_itemArrayList = list_itemArrayList;
    }

    @Override
    public int getCount() {
        return this.list_itemArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return this.list_itemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.item,null);
            txtName = (TextView)convertView.findViewById(R.id.txtName);
            txtTitle = (TextView)convertView.findViewById(R.id.txtTitle);
            txtDate = (TextView)convertView.findViewById(R.id.txtDate);
            txtContent = (TextView)convertView.findViewById(R.id.txtContent);
            imgProfile = (ImageView)convertView.findViewById(R.id.imgProfile);
        }
        txtName.setText(list_itemArrayList.get(position).getNickname());
        txtTitle.setText(list_itemArrayList.get(position).getTitle());
        txtContent.setText(list_itemArrayList.get(position).getContent());
        txtDate.setText(list_itemArrayList.get(position).getWrite_date().toString());
        imgProfile.setImageResource(list_itemArrayList.get(position).getProfile_image());

        return convertView;
    }
}
